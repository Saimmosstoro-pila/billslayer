# BillSlayer 💸

Negocia tus facturas con IA. Paga menos sin esfuerzo.

## Publicar en Vercel (sin computadora)

### Opción A — GitHub + Vercel (recomendada)

1. Crea cuenta en **github.com**
2. Crea un repositorio nuevo llamado `billslayer`
3. Sube todos estos archivos
4. Ve a **vercel.com** → "New Project"
5. Conecta tu GitHub → selecciona `billslayer`
6. Click "Deploy" → listo en 2 minutos

### Opción B — Vercel CLI

```bash
npm install -g vercel
vercel --prod
```

## Instalar como app en iPhone

1. Abre el link de Vercel en **Safari**
2. Toca el botón de compartir (cuadrado con flecha)
3. "Agregar a pantalla de inicio"
4. Ponle nombre "BillSlayer"
5. Ya tienes el ícono en tu celular 🎉

## Estructura del proyecto

```
billslayer/
├── public/
│   ├── manifest.json    # PWA config
│   └── icon.svg         # Ícono de la app
├── src/
│   ├── App.jsx          # App completa
│   └── main.jsx         # Entry point
├── index.html
├── package.json
├── vite.config.js
└── vercel.json
```

## Stack
- React 18
- Vite
- Claude AI API (negociación en vivo + escaneo de facturas)
- Stripe (pagos $5/mes)
