import { useState, useRef, useEffect } from "react";

const PROVIDER_INFO = {
  "Frontier":      { phone:"1-800-921-8101", hours:"Lun–Vie 8am–8pm CT", best:"Martes 9–11am", reasons:["Llevas 6+ meses — elegible para descuento de lealtad","AT&T ofrece $30/mes en tu área actualmente","La promo de nuevos clientes es 35% más barata que tu tarifa"], tactics:["Pide hablar con el departamento de retención","Menciona que comparaste con Spectrum","Si dicen no, pide hablar con un supervisor"] },
  "Verizon":       { phone:"1-800-922-0204", hours:"Lun–Dom 7am–11pm CT", best:"Lunes por la mañana", reasons:["Clientes nuevos pagan $65 — tú pagas $85 por lo mismo","Llevas 12 meses sin pedir nunca un ajuste","T-Mobile ofrece plan similar por $55/mes"], tactics:["Di que recibiste oferta de T-Mobile","Pide el plan Welcome Unlimited para clientes existentes","Amenaza con portar tu número si no ajustan"] },
  "Just Energy":   { phone:"1-866-587-8674", hours:"Lun–Vie 7am–7pm CT",  best:"Viernes antes de las 5pm", reasons:["Texas tiene mercado libre — tienes derecho a comparar","TXU Energy tiene rate fijo más bajo este mes","Tu contrato puede tener penalidad de salida baja"], tactics:["Visita PowerToChoose.org para comparar tarifas","Negocia un rate fijo por 12 meses","Si no bajan, cambia a Green Mountain o Reliant"] },
  "Keystone Falls":{ phone:"Ver tu contrato", hours:"Lun–Vie 9am–5pm", best:"Al renovar contrato", reasons:["Llevas 12 meses — eres inquilino confiable","Unidades similares en el área cuestan menos","Puedes negociar mejoras en vez de bajada"], tactics:["Pide waiver de late fees","Solicita mejoras al renovar (pintura, appliances)","Negocia si firmas 18 meses en vez de 12"] },
  "Capital One":   { phone:"1-800-227-4825", hours:"24/7", best:"Cualquier momento", reasons:["24 meses de pagos puntuales — eres cliente ideal","Tu APR puede reducirse 3–5 puntos","Capital One tiene programa interno de fidelidad"], tactics:["Pide específicamente una reducción de APR","Menciona que tienes ofertas de otras tarjetas","Si hay fee anual, pide que lo eliminen"] },
};

const BILLS = [
  { id:1, provider:"Frontier",      icon:"🌐", category:"Internet",     amount:40.80,  dueDate:"May 21", dueIn:9,  savings:15, months:6,  marketAvg:35,   negotiable:true,  tip:"Estás 16% sobre el promedio de Dallas." },
  { id:2, provider:"Verizon",        icon:"📱", category:"Wireless",     amount:85.00,  dueDate:"May 24", dueIn:12, savings:20, months:12, marketAvg:65,   negotiable:true,  tip:"Clientes nuevos pagan $65. Llevas 12 meses." },
  { id:3, provider:"Just Energy",    icon:"⚡", category:"Electricidad", amount:120.00, dueDate:"Jun 1",  dueIn:20, savings:12, months:8,  marketAvg:108,  negotiable:true,  tip:"Texas tiene mercado libre. Compara tarifas." },
  { id:4, provider:"Keystone Falls", icon:"🏠", category:"Renta",        amount:1250,   dueDate:"Jun 1",  dueIn:20, savings:0,  months:12, marketAvg:1180, negotiable:false, tip:"Pide waiver de fees al renovar contrato." },
  { id:5, provider:"Capital One",    icon:"💳", category:"Tarjeta",      amount:45.00,  dueDate:"May 19", dueIn:7,  savings:0,  months:24, marketAvg:0,    negotiable:true,  tip:"Solicita reducción de APR. 24 meses de historial." },
];

const HISTORY_INIT = [];

const fmt  = n => "$" + Number(n).toFixed(2);
const fmtN = n => "$" + Math.round(n);

const G = `
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Syne:wght@700;800&family=DM+Serif+Display&display=swap');
  *{box-sizing:border-box;margin:0;padding:0;}
  body,input,button,textarea{font-family:'Plus Jakarta Sans',sans-serif;}
  ::-webkit-scrollbar{display:none;}
  @keyframes spin{to{transform:rotate(360deg);}}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
  @keyframes up{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
`;

function Tag({ tone, children }) {
  tone = tone || "gray";
  const m = { gray:["#f4f4f5","#52525b"], green:["#ecfdf5","#065f46"], amber:["#fffbeb","#92600a"], red:["#fef2f2","#991b1b"], blue:["#eff6ff","#1e40af"], purple:["#f5f3ff","#5b21b6"] };
  const bg = m[tone][0];
  const fg = m[tone][1];
  return <span style={{background:bg,color:fg,fontSize:10,fontWeight:700,padding:"3px 9px",borderRadius:20,whiteSpace:"nowrap"}}>{children}</span>;
}

function PrimaryBtn({ children, onClick, disabled, style: sx }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{width:"100%",padding:"13px 20px",background:disabled?"#e4e4e7":"#111",color:disabled?"#a1a1aa":"#fff",border:"none",borderRadius:12,fontSize:14,fontWeight:700,cursor:disabled?"default":"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8,...(sx||{})}}>
      {children}
    </button>
  );
}

function GhostBtn({ children, onClick, style: sx }) {
  return (
    <button onClick={onClick} style={{padding:"12px 18px",background:"#f4f4f5",color:"#111",border:"none",borderRadius:12,fontSize:13,fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:6,...(sx||{})}}>
      {children}
    </button>
  );
}

function Field({ label, ...rest }) {
  return (
    <div>
      {label && <p style={{fontSize:11,fontWeight:700,color:"#71717a",textTransform:"uppercase",letterSpacing:.6,marginBottom:6}}>{label}</p>}
      <input {...rest} style={{width:"100%",padding:"12px 14px",border:"1.5px solid #e4e4e7",borderRadius:11,fontSize:14,background:"#fafafa",color:"#111",...(rest.style||{})}} onFocus={e=>e.target.style.borderColor="#111"} onBlur={e=>e.target.style.borderColor="#e4e4e7"} />
    </div>
  );
}

function PriceBar({ amount, marketAvg, savings }) {
  if (!amount || !marketAvg) return null;
  const max    = Math.max(amount, marketAvg) * 1.2;
  const youPct = Math.round((amount / max) * 100);
  const mktPct = Math.round((marketAvg / max) * 100);
  const diff   = Math.round(((amount - marketAvg) / marketAvg) * 100);
  const over   = amount > marketAvg;
  return (
    <div style={{background:over?"#fff8f8":"#f8fff9",borderRadius:10,padding:"10px 12px",border:"1px solid " + (over?"#fee2e2":"#dcfce7")}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:7}}>
        <span style={{fontSize:10,fontWeight:700,color:"#71717a",textTransform:"uppercase",letterSpacing:".4px"}}>vs mercado</span>
        <span style={{fontSize:11,fontWeight:800,color:over?"#dc2626":"#16a34a"}}>
          {over ? "+" + diff + "% más caro" : "-" + Math.abs(diff) + "% ✓"}
        </span>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:5}}>
        <div style={{display:"flex",alignItems:"center",gap:7}}>
          <span style={{fontSize:9,color:"#a1a1aa",width:42,flexShrink:0,textAlign:"right"}}>Tú</span>
          <div style={{flex:1,height:18,background:"#f0f0f0",borderRadius:4,overflow:"hidden"}}>
            <div style={{height:"100%",width:youPct+"%",background:over?"#f87171":"#4ade80",borderRadius:4,display:"flex",alignItems:"center",justifyContent:"flex-end",paddingRight:6,transition:"width .6s ease"}}>
              <span style={{color:"#fff",fontSize:9,fontWeight:800}}>{fmtN(amount)}</span>
            </div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:7}}>
          <span style={{fontSize:9,color:"#a1a1aa",width:42,flexShrink:0,textAlign:"right"}}>Mkt</span>
          <div style={{flex:1,height:18,background:"#f0f0f0",borderRadius:4,overflow:"hidden"}}>
            <div style={{height:"100%",width:mktPct+"%",background:"#4ade80",borderRadius:4,display:"flex",alignItems:"center",justifyContent:"flex-end",paddingRight:6,transition:"width .6s ease"}}>
              <span style={{color:"#fff",fontSize:9,fontWeight:800}}>{fmtN(marketAvg)}</span>
            </div>
          </div>
        </div>
      </div>
      {over && savings > 0 && (
        <p style={{color:"#dc2626",fontSize:10,fontWeight:700,margin:"7px 0 0",textAlign:"center"}}>
          Ahorra ${savings}/mes · ${savings*12}/año
        </p>
      )}
    </div>
  );
}

const NavIcons = {
  home: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
  scan: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg>,
  live: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>,
  history: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
  profile: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
};

// ── Login ─────────────────────────────────────────────────────────────────────
function Login({ onLogin }) {
  const [mode, setMode] = useState("in");
  const [v, setV] = useState({ name:"", email:"", pass:"" });
  const s = k => e => setV(p => ({...p, [k]: e.target.value}));
  return (
    <div style={{minHeight:"100vh",background:"#fff",display:"flex",flexDirection:"column",justifyContent:"center",padding:"0 28px 48px",maxWidth:400,margin:"0 auto"}}>
      <style>{G}</style>
      <div style={{textAlign:"center",marginBottom:40}}>
        <div style={{width:68,height:68,background:"#111",borderRadius:20,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px",boxShadow:"0 8px 28px rgba(0,0,0,.12)"}}><span style={{color:"#fff",fontFamily:"'DM Serif Display',serif",fontWeight:700,fontSize:36,lineHeight:1}}>$</span></div>
        <h1 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:34,color:"#111",marginBottom:6,letterSpacing:"-.5px"}}>BillSlayer</h1>
        <p style={{color:"#a1a1aa",fontSize:14}}>Paga menos. Sin esfuerzo.</p>
      </div>
      <div style={{display:"flex",background:"#f4f4f5",borderRadius:12,padding:3,marginBottom:24}}>
        {[["in","Iniciar sesión"],["up","Crear cuenta"]].map(function(item) {
          return <button key={item[0]} onClick={() => setMode(item[0])} style={{flex:1,padding:"9px",border:"none",borderRadius:10,background:mode===item[0]?"#fff":"transparent",color:mode===item[0]?"#111":"#71717a",fontWeight:700,fontSize:13,cursor:"pointer",boxShadow:mode===item[0]?"0 1px 4px rgba(0,0,0,.08)":"none"}}>{item[1]}</button>;
        })}
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:12,marginBottom:16}}>
        {mode === "up" && <Field label="Nombre" value={v.name} onChange={s("name")} placeholder="Jose Mendoza" />}
        <Field label="Correo" type="email" value={v.email} onChange={s("email")} placeholder="jose@gmail.com" />
        <Field label="Contraseña" type="password" value={v.pass} onChange={s("pass")} placeholder="••••••••" />
      </div>
      <PrimaryBtn onClick={() => onLogin({name: v.name || "Jose Mendoza", email: v.email || "saimmosstoro@gmail.com"})} style={{marginBottom:14,borderRadius:12,boxShadow:"0 4px 16px rgba(0,0,0,.1)"}}>
        {mode === "in" ? "Entrar" : "Registrarse"}
      </PrimaryBtn>
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
        <div style={{flex:1,height:1,background:"#f0f0f0"}} />
        <span style={{color:"#c4c4c4",fontSize:11}}>o</span>
        <div style={{flex:1,height:1,background:"#f0f0f0"}} />
      </div>
      <GhostBtn onClick={() => onLogin({name:"Jose Mendoza", email:"saimmosstoro@gmail.com"})} style={{width:"100%",borderRadius:12}}>
        <span style={{fontSize:17}}>🔵</span> Continuar con Google
      </GhostBtn>
    </div>
  );
}

// ── Payment ───────────────────────────────────────────────────────────────────
function Payment({ onSuccess }) {
  const [step, setStep] = useState("plan");
  const [card, setCard] = useState({number:"", expiry:"", cvc:"", name:""});
  const updateCard = function(key, val) { setCard(function(p) { return {...p, [key]: val}; }); };

  const handleCardChange = function(key) {
    return function(e) {
      var v = e.target.value.replace(/\D/g, "");
      if (key === "number") v = v.slice(0,16).replace(/(.{4})/g,"$1 ").trim();
      if (key === "expiry") { v = v.slice(0,4); if (v.length > 2) v = v.slice(0,2) + "/" + v.slice(2); }
      if (key === "cvc") v = v.slice(0,3);
      if (key === "name") v = e.target.value;
      updateCard(key, v);
    };
  };

  const canPay = card.number.length >= 19 && card.expiry.length >= 5 && card.cvc.length >= 3 && card.name.length > 0;

  const process = function() {
    setStep("processing");
    setTimeout(function() { setStep("done"); }, 2800);
  };

  return (
    <div style={{minHeight:"100vh",background:"#fafafa",display:"flex",flexDirection:"column"}}>
      <style>{G}</style>
      <div style={{background:"#fff",borderBottom:"1px solid #f0f0f0",padding:"18px 24px",display:"flex",alignItems:"center",gap:12}}>
        <div style={{width:32,height:32,background:"#111",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16}}>💸</div>
        <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:18,color:"#111"}}>BillSlayer</span>
        <div style={{marginLeft:"auto"}}><Tag tone="blue">🔒 Pago seguro</Tag></div>
      </div>
      <div style={{flex:1,padding:"28px 24px",maxWidth:420,margin:"0 auto",width:"100%"}}>

        {step === "plan" && (
          <div style={{animation:"up .3s ease"}}>
            <h1 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:26,color:"#111",marginBottom:6}}>Activa tu cuenta</h1>
            <p style={{color:"#71717a",fontSize:14,marginBottom:24,lineHeight:1.6}}>Empieza a ahorrar en tus facturas hoy mismo.</p>
            <div style={{background:"#111",borderRadius:20,padding:24,marginBottom:20}}>
              <p style={{color:"#525252",fontSize:11,textTransform:"uppercase",letterSpacing:"1.4px",margin:"0 0 8px"}}>Plan BillSlayer</p>
              <div style={{display:"flex",alignItems:"flex-end",gap:4,marginBottom:16}}>
                <span style={{fontFamily:"'DM Serif Display',serif",fontWeight:900,fontSize:48,color:"#fff",lineHeight:1}}>$5</span>
                <span style={{color:"#525252",fontSize:14,paddingBottom:8}}>/mes</span>
              </div>
              <div style={{borderTop:"1px solid #1c1c1c",paddingTop:14,display:"flex",flexDirection:"column",gap:8}}>
                {["Estrategias de negociación con IA","Negociación en vivo durante tu llamada","Escaneo de facturas con cámara","Historial de todas tus negociaciones","Soporte incluido"].map(function(f, i) {
                  return (
                    <div key={i} style={{display:"flex",gap:10,alignItems:"center"}}>
                      <div style={{width:18,height:18,borderRadius:"50%",background:"rgba(34,197,94,.15)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                        <span style={{color:"#22c55e",fontSize:10,fontWeight:800}}>✓</span>
                      </div>
                      <span style={{color:"#a1a1aa",fontSize:13}}>{f}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div style={{background:"#f0fdf4",border:"1px solid #bbf7d0",borderRadius:14,padding:16,marginBottom:24}}>
              <p style={{fontWeight:700,color:"#14532d",fontSize:13,marginBottom:8}}>💡 Promedio de nuestros usuarios</p>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                <div>
                  <p style={{color:"#16a34a",fontFamily:"'DM Serif Display',serif",fontWeight:700,fontSize:22,margin:"0 0 2px"}}>$1,247/año</p>
                  <p style={{color:"#4ade80",fontSize:11,margin:0}}>Ahorro promedio</p>
                </div>
                <div>
                  <p style={{color:"#16a34a",fontFamily:"'DM Serif Display',serif",fontWeight:700,fontSize:22,margin:"0 0 2px"}}>×20</p>
                  <p style={{color:"#4ade80",fontSize:11,margin:0}}>ROI del plan</p>
                </div>
              </div>
            </div>
            <PrimaryBtn onClick={() => setStep("card")} style={{borderRadius:14,padding:"15px",fontSize:15}}>
              Continuar al pago →
            </PrimaryBtn>
            <p style={{textAlign:"center",color:"#a1a1aa",fontSize:11,marginTop:12}}>Cancela cuando quieras · Sin contratos</p>
          </div>
        )}

        {step === "card" && (
          <div style={{animation:"up .3s ease"}}>
            <button onClick={() => setStep("plan")} style={{display:"flex",alignItems:"center",gap:6,background:"none",border:"none",cursor:"pointer",color:"#71717a",fontSize:13,fontWeight:600,marginBottom:20,padding:0}}>← Volver</button>
            <h1 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:24,color:"#111",marginBottom:4}}>Datos de pago</h1>
            <p style={{color:"#71717a",fontSize:13,marginBottom:20}}>Tu suscripción de $5.00/mes empieza hoy.</p>
            <div style={{background:"#fff",border:"1.5px solid #f0f0f0",borderRadius:14,padding:"12px 16px",marginBottom:20,display:"flex",alignItems:"center",gap:10}}>
              <div style={{background:"#635BFF",borderRadius:6,padding:"4px 8px"}}>
                <span style={{color:"#fff",fontWeight:800,fontSize:12}}>stripe</span>
              </div>
              <div style={{flex:1}}>
                <p style={{fontWeight:700,color:"#111",fontSize:12,margin:"0 0 1px"}}>Powered by Stripe</p>
                <p style={{color:"#a1a1aa",fontSize:10,margin:0}}>256-bit SSL · Datos encriptados</p>
              </div>
              <span style={{color:"#22c55e",fontSize:16}}>🔒</span>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:14,marginBottom:20}}>
              <div>
                <p style={{fontSize:11,fontWeight:700,color:"#71717a",textTransform:"uppercase",letterSpacing:".6px",marginBottom:6}}>Número de tarjeta</p>
                <input value={card.number} onChange={handleCardChange("number")} placeholder="1234 5678 9012 3456" style={{width:"100%",padding:"12px 14px",border:"1.5px solid #e4e4e7",borderRadius:11,fontSize:15,letterSpacing:"1px",background:"#fafafa"}} onFocus={e=>e.target.style.borderColor="#111"} onBlur={e=>e.target.style.borderColor="#e4e4e7"} />
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                <Field label="Vencimiento" value={card.expiry} onChange={handleCardChange("expiry")} placeholder="MM/AA" />
                <Field label="CVC" value={card.cvc} onChange={handleCardChange("cvc")} placeholder="123" />
              </div>
              <Field label="Nombre en la tarjeta" value={card.name} onChange={handleCardChange("name")} placeholder="Jose Mendoza" />
            </div>
            <div style={{background:"#fafafa",border:"1px solid #f0f0f0",borderRadius:12,padding:"12px 16px",marginBottom:16}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{color:"#52525b",fontSize:13}}>Plan BillSlayer · mensual</span>
                <span style={{fontWeight:700,color:"#111",fontSize:14}}>$5.00</span>
              </div>
              <div style={{display:"flex",justifyContent:"space-between",paddingTop:8,borderTop:"1px solid #f0f0f0"}}>
                <span style={{fontWeight:700,color:"#111",fontSize:13}}>Total hoy</span>
                <span style={{fontFamily:"'DM Serif Display',serif",fontWeight:900,color:"#111",fontSize:18}}>$5.00</span>
              </div>
            </div>
            <button onClick={process} disabled={!canPay} style={{width:"100%",padding:"14px",background:canPay?"#635BFF":"#e4e4e7",color:canPay?"#fff":"#a1a1aa",border:"none",borderRadius:14,fontSize:15,fontWeight:700,cursor:canPay?"pointer":"default",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
              🔒 Pagar $5.00 con Stripe
            </button>
            <p style={{textAlign:"center",color:"#a1a1aa",fontSize:11,marginTop:10}}>Tus datos nunca se guardan en nuestros servidores</p>
          </div>
        )}

        {step === "processing" && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"60vh",gap:24}}>
            <div style={{position:"relative",width:80,height:80}}>
              <div style={{position:"absolute",inset:0,borderRadius:"50%",border:"3px solid #f0f0f0",borderTopColor:"#635BFF",animation:"spin .8s linear infinite"}} />
              <div style={{position:"absolute",inset:8,borderRadius:"50%",border:"2px solid #f0f0f0",borderTopColor:"#22c55e",animation:"spin 1.2s linear infinite reverse"}} />
              <div style={{position:"absolute",inset:20,borderRadius:"50%",background:"#f5f3ff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>💳</div>
            </div>
            <div style={{textAlign:"center"}}>
              <p style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:20,color:"#111",marginBottom:6}}>Procesando pago…</p>
              <p style={{color:"#a1a1aa",fontSize:13}}>Conectando con Stripe de forma segura</p>
            </div>
          </div>
        )}

        {step === "done" && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"48px 0",textAlign:"center",animation:"up .4s ease"}}>
            <div style={{width:88,height:88,background:"#f0fdf4",border:"3px solid #86efac",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:38,marginBottom:24}}>✅</div>
            <h1 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:28,color:"#111",marginBottom:6}}>¡Pago exitoso!</h1>
            <p style={{color:"#71717a",fontSize:14,lineHeight:1.7,marginBottom:8}}>Tu cuenta está activa. Ya puedes negociar tus facturas.</p>
            <div style={{background:"#f0fdf4",borderRadius:12,padding:"8px 20px",marginBottom:32}}>
              <p style={{color:"#16a34a",fontWeight:700,fontSize:13}}>Próximo cobro: Jun 12, 2026 · $5.00</p>
            </div>
            <PrimaryBtn onClick={onSuccess} style={{width:"auto",padding:"12px 28px",borderRadius:12,fontSize:15}}>Ir a mi dashboard →</PrimaryBtn>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Scan ──────────────────────────────────────────────────────────────────────
function ScanModal({ onClose, onAdd }) {
  const [step, setStep] = useState("pick");
  const [img,  setImg]  = useState(null);
  const [conf, setConf] = useState(0);
  const [form, setForm] = useState({provider:"",category:"",amount:"",dueDate:""});
  const fileRef = useRef(); const camRef = useRef();
  const sf = function(k) { return function(e) { setForm(function(p) { return {...p, [k]: e.target.value}; }); }; };

  const load = function(f) {
    if (!f) return;
    var r = new FileReader();
    r.onload = function(e) { setImg(e.target.result); setStep("preview"); };
    r.readAsDataURL(f);
  };

  const scan = async function() {
    setStep("scanning");
    try {
      var b64 = img.split(",")[1];
      var mt  = img.split(";")[0].split(":")[1];
      var res = await fetch("https://api.anthropic.com/v1/messages", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:250,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:mt,data:b64}},{type:"text",text:'Extract bill. JSON only:\n{"provider":"","category":"","amount":null,"dueDate":"","confidence":0}'}]}]})});
      var data = await res.json();
      var text = data && data.content && data.content.find(function(b) { return b.type === "text"; });
      var p = JSON.parse(text ? text.text.replace(/```json|```/g,"").trim() : "{}");
      setConf(p.confidence || 0);
      setForm({provider:p.provider||"",category:p.category||"",amount:p.amount?String(p.amount):"",dueDate:p.dueDate||""});
      setStep("form");
    } catch(e) { setStep("form"); }
  };

  const save = function() {
    var amt = form.amount ? parseFloat(form.amount) : null;
    onAdd({id:Date.now(),provider:form.provider||"Proveedor",icon:"📄",category:form.category||"Otro",amount:amt,dueDate:form.dueDate||"—",dueIn:15,savings:amt?Math.round(amt*.18):0,months:1,marketAvg:amt?amt*.85:0,negotiable:true,tip:"Factura añadida manualmente.",photoData:img});
    setStep("done");
  };

  return (
    <div style={{position:"fixed",inset:0,background:"#fff",zIndex:200,display:"flex",flexDirection:"column"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,padding:"18px 20px",borderBottom:"1px solid #f4f4f5"}}>
        <button onClick={onClose} style={{width:34,height:34,borderRadius:"50%",border:"1.5px solid #e4e4e7",background:"#fff",cursor:"pointer",fontSize:17,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
        <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:19,color:"#111"}}>Agregar factura</h2>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"24px 20px",maxWidth:420,margin:"0 auto",width:"100%"}}>

        {step === "pick" && (
          <div>
            <p style={{color:"#71717a",fontSize:13,lineHeight:1.7,marginBottom:24}}>Toma foto o sube de galería. La IA lee los datos automáticamente.</p>
            <input ref={camRef}  type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={function(e) { load(e.target.files[0]); }} />
            <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={function(e) { load(e.target.files[0]); }} />
            <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:20}}>
              <button onClick={function() { camRef.current.click(); }} style={{padding:"18px 20px",background:"#111",border:"none",borderRadius:14,color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",gap:14}}>
                <span style={{fontSize:26}}>📸</span>
                <div style={{textAlign:"left"}}>
                  <p style={{fontWeight:700,fontSize:14,margin:"0 0 2px"}}>Tomar foto</p>
                  <p style={{fontSize:11,color:"#71717a",margin:0}}>Abre la cámara</p>
                </div>
              </button>
              <button onClick={function() { fileRef.current.click(); }} style={{padding:"18px 20px",background:"#fafafa",border:"1.5px solid #e4e4e7",borderRadius:14,color:"#111",cursor:"pointer",display:"flex",alignItems:"center",gap:14}}>
                <span style={{fontSize:26}}>🖼️</span>
                <div style={{textAlign:"left"}}>
                  <p style={{fontWeight:700,fontSize:14,margin:"0 0 2px"}}>Subir de galería</p>
                  <p style={{fontSize:11,color:"#a1a1aa",margin:0}}>Elige una imagen</p>
                </div>
              </button>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}>
              <div style={{flex:1,height:1,background:"#f0f0f0"}} /><span style={{color:"#c4c4c4",fontSize:11}}>o ingresa manualmente</span><div style={{flex:1,height:1,background:"#f0f0f0"}} />
            </div>
            <GhostBtn onClick={function() { setStep("form"); }} style={{width:"100%",borderRadius:12}}>✏️ Entrada manual</GhostBtn>
          </div>
        )}

        {step === "preview" && img && (
          <div>
            <div style={{borderRadius:14,overflow:"hidden",marginBottom:18,maxHeight:280,border:"1px solid #f4f4f5"}}><img src={img} alt="bill" style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}} /></div>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              <PrimaryBtn onClick={scan} style={{borderRadius:12}}>🤖 Leer con IA</PrimaryBtn>
              <GhostBtn onClick={function() { setStep("pick"); }} style={{width:"100%",borderRadius:12}}>Tomar otra foto</GhostBtn>
            </div>
          </div>
        )}

        {step === "scanning" && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"56px 0"}}>
            {img && <div style={{width:88,height:88,borderRadius:14,overflow:"hidden",marginBottom:24,position:"relative"}}><img src={img} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}} /><div style={{position:"absolute",inset:0,background:"rgba(0,0,0,.45)",display:"flex",alignItems:"center",justifyContent:"center"}}><div style={{width:28,height:28,border:"3px solid rgba(255,255,255,.25)",borderTopColor:"#fff",borderRadius:"50%",animation:"spin .8s linear infinite"}} /></div></div>}
            <p style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:20,color:"#111",marginBottom:6}}>Analizando imagen…</p>
            <p style={{color:"#a1a1aa",fontSize:13}}>La IA está leyendo tu factura</p>
          </div>
        )}

        {step === "form" && (
          <div>
            {img && conf > 0 && (
              <div style={{background:conf>=70?"#f0fdf4":"#fffbeb",border:"1px solid " + (conf>=70?"#bbf7d0":"#fde68a"),borderRadius:12,padding:"10px 14px",marginBottom:18,display:"flex",gap:8,alignItems:"center"}}>
                <span>{conf >= 70 ? "✅" : "⚠️"}</span>
                <p style={{fontSize:12,color:conf>=70?"#14532d":"#92600a",margin:0}}>{conf >= 70 ? "Factura detectada" : "Lectura parcial"} · Confianza {conf}%</p>
              </div>
            )}
            <div style={{display:"flex",flexDirection:"column",gap:12,marginBottom:20}}>
              <Field label="Proveedor"   value={form.provider} onChange={sf("provider")} placeholder="AT&T, Frontier…" />
              <Field label="Categoría"   value={form.category} onChange={sf("category")} placeholder="Internet, Seguro…" />
              <Field label="Monto/mes"   value={form.amount}   onChange={sf("amount")}   placeholder="89.99" type="number" />
              <Field label="Vencimiento" value={form.dueDate}  onChange={sf("dueDate")}  placeholder="May 21, 2026" />
            </div>
            <div style={{display:"flex",gap:10}}>
              <GhostBtn onClick={function() { setStep("pick"); }} style={{flex:1,borderRadius:12}}>← Atrás</GhostBtn>
              <PrimaryBtn onClick={save} style={{flex:2,borderRadius:12}}>Guardar ✓</PrimaryBtn>
            </div>
          </div>
        )}

        {step === "done" && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"64px 0",textAlign:"center"}}>
            <div style={{width:72,height:72,background:"#f0fdf4",border:"2px solid #86efac",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,marginBottom:20}}>✅</div>
            <p style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:24,color:"#111",marginBottom:6}}>¡Factura agregada!</p>
            <p style={{color:"#a1a1aa",fontSize:13,marginBottom:28,lineHeight:1.6}}>Ya aparece en tu dashboard lista para negociar.</p>
            <PrimaryBtn onClick={onClose} style={{width:"auto",padding:"12px 28px",borderRadius:12}}>Ver mis facturas →</PrimaryBtn>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Live Negotiation ──────────────────────────────────────────────────────────
function LiveNeg({ bill, onClose, onSave }) {
  const [msgs,   setMsgs]   = useState([{ai:true, text:"¡Negociación en vivo con " + bill.provider + "! 🎯\n\nLlama a su servicio al cliente.\nEscribe exactamente lo que te digan y te digo qué responder."}]);
  const [input,  setInput]  = useState("");
  const [busy,   setBusy]   = useState(false);
  const [win,    setWin]    = useState(false);
  const [saved,  setSaved]  = useState("");
  const endRef = useRef(null);

  useEffect(function() { endRef.current && endRef.current.scrollIntoView({behavior:"smooth"}); }, [msgs]);

  const send = async function() {
    if (!input.trim() || busy) return;
    var txt = input.trim(); setInput(""); setBusy(true);
    setMsgs(function(p) { return [...p, {ai:false, text:txt}]; });
    try {
      var history = msgs.map(function(m) { return {role: m.ai ? "assistant" : "user", content: m.text}; });
      var res = await fetch("https://api.anthropic.com/v1/messages", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:300,system:"Coach experto en negociación. Usuario en llamada EN VIVO con " + bill.provider + ". Tarifa: " + fmt(bill.amount||0) + "/mes. Mercado: " + fmtN(bill.marketAvg||0) + "/mes. Responde solo en español, máx 3 oraciones, exactamente qué decir. Formato: DI ESTO: seguido del script entre comillas. Si logró ahorrar: empieza con EXITO!",messages:[...history,{role:"user",content:txt}]})});
      var data = await res.json();
      var textBlock = data && data.content && data.content.find(function(b) { return b.type === "text"; });
      var text = textBlock ? textBlock.text : "Intenta de nuevo.";
      setMsgs(function(p) { return [...p, {ai:true, text:text}]; });
      if (text.indexOf("EXITO!") === 0) setWin(true);
    } catch(e) {
      setMsgs(function(p) { return [...p, {ai:true, text:"Sin conexión. Script: He visto que clientes nuevos pagan " + fmtN(bill.marketAvg||0) + "/mes. ¿Pueden igualar esa tarifa?"}]; });
    }
    setBusy(false);
  };

  return (
    <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",flexDirection:"column",background:"#fff"}}>
      <div style={{background:"#111",padding:"14px 20px",display:"flex",alignItems:"center",gap:10}}>
        <div style={{width:8,height:8,borderRadius:"50%",background:"#22c55e",animation:"pulse 1.5s ease infinite",flexShrink:0}} />
        <div style={{flex:1}}>
          <p style={{color:"#fff",fontFamily:"'Syne',sans-serif",fontWeight:700,fontSize:15,margin:0}}>En vivo — {bill.provider}</p>
          <p style={{color:"#525252",fontSize:11,margin:0}}>Coach IA en tiempo real</p>
        </div>
        <button onClick={onClose} style={{width:30,height:30,borderRadius:"50%",border:"1px solid #333",background:"transparent",color:"#fff",cursor:"pointer",fontSize:14,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
      </div>
      <div style={{padding:"10px 20px",background:"#fafafa",borderBottom:"1px solid #f0f0f0",display:"flex",gap:20}}>
        {[["Tu tarifa", fmt(bill.amount||0), "#dc2626"], ["Mercado", fmtN(bill.marketAvg||0), "#16a34a"], ["Meta", "-$" + (bill.savings||0) + "/mo", "#0284c7"]].map(function(item) {
          return (
            <div key={item[0]} style={{textAlign:"center"}}>
              <p style={{color:"#a1a1aa",fontSize:9,textTransform:"uppercase",letterSpacing:".5px",margin:"0 0 1px"}}>{item[0]}</p>
              <p style={{color:item[2],fontFamily:"'DM Serif Display',serif",fontWeight:700,fontSize:13,margin:0}}>{item[1]}</p>
            </div>
          );
        })}
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"16px 20px",display:"flex",flexDirection:"column",gap:10}}>
        {msgs.map(function(m, i) {
          return (
            <div key={i} style={{display:"flex",justifyContent:m.ai?"flex-start":"flex-end"}}>
              <div style={{maxWidth:"80%",padding:"11px 14px",borderRadius:m.ai?"4px 16px 16px 16px":"16px 16px 4px 16px",background:m.ai?"#f4f4f5":"#111"}}>
                {m.ai && <p style={{color:"#a1a1aa",fontSize:9,fontWeight:700,textTransform:"uppercase",letterSpacing:".5px",margin:"0 0 4px"}}>🤖 Coach IA</p>}
                <p style={{color:m.ai?"#111":"#fff",fontSize:13,lineHeight:1.7,margin:0,whiteSpace:"pre-wrap"}}>{m.text}</p>
              </div>
            </div>
          );
        })}
        {busy && (
          <div style={{display:"flex",gap:5,alignItems:"center"}}>
            <span style={{fontSize:13}}>🤖</span>
            {[0,1,2].map(function(i) { return <div key={i} style={{width:5,height:5,borderRadius:"50%",background:"#d4d4d8",animation:"pulse 1s ease " + (i*.2) + "s infinite"}} />; })}
          </div>
        )}
        <div ref={endRef} />
      </div>
      {win && (
        <div style={{padding:"14px 20px",background:"#f0fdf4",borderTop:"1px solid #bbf7d0"}}>
          <p style={{fontWeight:700,color:"#14532d",fontSize:13,marginBottom:8}}>🎉 ¡Éxito! ¿Cuánto lograste ahorrar?</p>
          <div style={{display:"flex",gap:8,marginBottom:10}}>
            <input value={saved} onChange={function(e) { setSaved(e.target.value); }} type="number" placeholder="ej: 25" style={{flex:1,padding:"10px 14px",border:"1.5px solid #bbf7d0",borderRadius:10,fontSize:14}} />
            <span style={{display:"flex",alignItems:"center",color:"#52525b",fontSize:13}}>/mes</span>
          </div>
          <PrimaryBtn onClick={function() {
            onSave({id:Date.now(),provider:bill.provider,icon:bill.icon,date:new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}),ok:true,saved:parseInt(saved)||bill.savings||0,before:bill.amount||0,after:(bill.amount||0)-(parseInt(saved)||0),note:msgs.filter(function(m) { return !m.ai; }).map(function(m) { return m.text; }).join(" → ")});
            onClose();
          }} style={{borderRadius:10}}>Guardar en historial →</PrimaryBtn>
        </div>
      )}
      {!win && (
        <div style={{padding:"12px 20px 28px",borderTop:"1px solid #f4f4f5",display:"flex",gap:10}}>
          <input value={input} onChange={function(e) { setInput(e.target.value); }} onKeyDown={function(e) { if (e.key==="Enter") send(); }} placeholder="Escribe lo que te dicen…" style={{flex:1,padding:"11px 16px",border:"1.5px solid #e4e4e7",borderRadius:24,fontSize:14}} onFocus={function(e) { e.target.style.borderColor="#111"; }} onBlur={function(e) { e.target.style.borderColor="#e4e4e7"; }} />
          <button onClick={send} disabled={!input.trim() || busy} style={{width:44,height:44,borderRadius:"50%",background:input.trim()?"#111":"#f4f4f5",border:"none",cursor:input.trim()?"pointer":"default",fontSize:18,color:input.trim()?"#fff":"#c4c4c4",display:"flex",alignItems:"center",justifyContent:"center"}}>
            {busy ? <div style={{width:14,height:14,border:"2px solid rgba(255,255,255,.3)",borderTopColor:"#fff",borderRadius:"50%",animation:"spin .8s linear infinite"}} /> : "↑"}
          </button>
        </div>
      )}
    </div>
  );
}

// ── History ───────────────────────────────────────────────────────────────────
function HistoryScreen({ items }) {
  var wins = items.filter(function(h) { return h.ok; });
  var total = wins.reduce(function(s, h) { return s + h.saved * 12; }, 0);
  var rate  = items.length ? Math.round((wins.length / items.length) * 100) : 0;
  return (
    <div>
      <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:22,color:"#111",marginBottom:18}}>Historial</h2>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:24}}>
        {[["Ahorrado/año","$" + total,"#16a34a"],["Total",items.length,"#111"],["Éxito",rate + "%","#0284c7"]].map(function(item) {
          return (
            <div key={item[0]} style={{background:"#fff",border:"1.5px solid #f4f4f5",borderRadius:14,padding:"14px 10px",textAlign:"center"}}>
              <p style={{fontFamily:"'DM Serif Display',serif",fontWeight:700,fontSize:22,color:item[2],margin:"0 0 3px"}}>{item[1]}</p>
              <p style={{color:"#a1a1aa",fontSize:9,textTransform:"uppercase",letterSpacing:".4px",margin:0}}>{item[0]}</p>
            </div>
          );
        })}
      </div>
      {items.map(function(h, i) {
        return (
          <div key={h.id} style={{display:"flex",gap:12,marginBottom:14}}>
            <div style={{display:"flex",flexDirection:"column",alignItems:"center"}}>
              <div style={{width:34,height:34,borderRadius:"50%",background:h.ok?"#f0fdf4":"#fef2f2",border:"2px solid " + (h.ok?"#86efac":"#fca5a5"),display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{h.ok ? "✅" : "❌"}</div>
              {i < items.length-1 && <div style={{width:2,flex:1,background:"#f4f4f5",margin:"4px 0"}} />}
            </div>
            <div style={{flex:1,background:"#fff",border:"1.5px solid #f4f4f5",borderRadius:14,padding:14,marginBottom:2}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                <div style={{display:"flex",gap:8,alignItems:"center"}}>
                  <span style={{fontSize:17}}>{h.icon}</span>
                  <div>
                    <p style={{fontWeight:700,color:"#111",fontSize:14,margin:"0 0 1px"}}>{h.provider}</p>
                    <p style={{color:"#a1a1aa",fontSize:11,margin:0}}>{h.date}</p>
                  </div>
                </div>
                {h.ok ? <p style={{color:"#16a34a",fontFamily:"'DM Serif Display',serif",fontWeight:700,fontSize:18,margin:0}}>-${h.saved}/mo</p> : <Tag tone="gray">Sin cambio</Tag>}
              </div>
              {h.ok && (
                <div style={{display:"flex",gap:7,alignItems:"center",marginBottom:8}}>
                  <span style={{color:"#dc2626",fontSize:12,textDecoration:"line-through",fontWeight:600}}>{fmt(h.before)}</span>
                  <span style={{color:"#c4c4c4"}}>→</span>
                  <span style={{color:"#16a34a",fontSize:14,fontWeight:700}}>{fmt(h.after)}</span>
                  <span style={{color:"#a1a1aa",fontSize:11}}>/mes</span>
                </div>
              )}
              <div style={{background:"#fafafa",borderRadius:10,padding:"9px 11px"}}>
                <p style={{color:"#a1a1aa",fontSize:9,textTransform:"uppercase",letterSpacing:".5px",margin:"0 0 3px"}}>Nota</p>
                <p style={{color:"#52525b",fontSize:12,lineHeight:1.6,margin:0}}>"{h.note}"</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Profile ───────────────────────────────────────────────────────────────────
function ProfileScreen({ user, emails, setEmails }) {
  const [adding, setAdding] = useState(false);
  const [neo,    setNeo]    = useState("");
  return (
    <div>
      <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:22,color:"#111",marginBottom:18}}>Perfil</h2>
      <div style={{background:"#111",borderRadius:18,padding:"18px 20px",marginBottom:14,display:"flex",gap:14,alignItems:"center"}}>
        <div style={{width:48,height:48,background:"rgba(255,255,255,.08)",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>👤</div>
        <div style={{flex:1,minWidth:0}}>
          <p style={{fontFamily:"'Syne',sans-serif",fontWeight:800,color:"#fff",fontSize:16,margin:"0 0 2px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.name}</p>
          <p style={{color:"#525252",fontSize:12,margin:"0 0 7px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.email}</p>
          <div style={{display:"flex",gap:6}}><Tag tone="green">$5/mes · Activo</Tag><Tag tone="blue">Dallas, TX</Tag></div>
        </div>
      </div>
      <div style={{background:"#f0fdf4",border:"1.5px solid #86efac",borderRadius:16,padding:"18px 20px",marginBottom:14}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
          <div>
            <p style={{fontWeight:700,color:"#111",fontSize:14,margin:"0 0 4px"}}>Plan activo</p>
            <p style={{fontFamily:"'DM Serif Display',serif",color:"#16a34a",fontWeight:900,fontSize:28,margin:0}}>$5.00<span style={{fontSize:12,fontWeight:400,color:"#71717a"}}>/mes</span></p>
          </div>
          <span style={{fontSize:26}}>✅</span>
        </div>
        <p style={{color:"#166534",fontSize:12,lineHeight:1.6,margin:"0 0 10px"}}>Acceso completo · Estrategias ilimitadas · Sin comisiones</p>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <Tag tone="green">Próximo cobro: Jun 12</Tag>
          <button style={{background:"none",border:"none",cursor:"pointer",color:"#dc2626",fontSize:11,fontWeight:600,padding:0}}>Cancelar plan</button>
        </div>
      </div>
      <div style={{marginBottom:20}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
          <p style={{fontWeight:700,color:"#111",fontSize:14}}>Correos enlazados</p>
          <GhostBtn onClick={function() { setAdding(function(p) { return !p; }); }} style={{padding:"6px 14px",borderRadius:20,fontSize:12}}>+ Añadir</GhostBtn>
        </div>
        {adding && (
          <div style={{background:"#fafafa",border:"1.5px solid #e4e4e7",borderRadius:12,padding:12,marginBottom:10}}>
            <div style={{display:"flex",gap:8}}>
              <input value={neo} onChange={function(e) { setNeo(e.target.value); }} placeholder="otro@gmail.com" style={{flex:1,padding:"9px 12px",border:"1.5px solid #e4e4e7",borderRadius:9,fontSize:13}} />
              <PrimaryBtn onClick={function() { if (neo.includes("@")) { setEmails(function(p) { return [...p, {id:Date.now(),address:neo,bills:0,connected:true,primary:false}]; }); setNeo(""); setAdding(false); } }} style={{width:"auto",padding:"9px 16px",borderRadius:9}}>✓</PrimaryBtn>
            </div>
          </div>
        )}
        {emails.map(function(em) {
          return (
            <div key={em.id} style={{background:"#fff",border:"1.5px solid #f4f4f5",borderRadius:12,padding:"12px 14px",marginBottom:8,display:"flex",alignItems:"center",gap:12}}>
              <div style={{width:36,height:36,background:"#f9fafb",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:17,flexShrink:0}}>📧</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:"flex",gap:5,alignItems:"center",marginBottom:2}}>
                  <p style={{fontWeight:600,color:"#111",fontSize:13,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",margin:0}}>{em.address}</p>
                  {em.primary && <Tag tone="green">Principal</Tag>}
                </div>
                <p style={{color:"#a1a1aa",fontSize:11,margin:0}}>{em.bills} facturas</p>
              </div>
              <div style={{display:"flex",gap:8,alignItems:"center",flexShrink:0}}>
                <div style={{width:7,height:7,borderRadius:"50%",background:em.connected?"#22c55e":"#e4e4e7"}} />
                {!em.primary && <button onClick={function() { setEmails(function(p) { return p.filter(function(e) { return e.id !== em.id; }); }); }} style={{background:"none",border:"none",cursor:"pointer",color:"#a1a1aa",fontSize:16,padding:0,lineHeight:1}}>✕</button>}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{borderTop:"1px solid #f4f4f5",paddingTop:16,marginBottom:16}}>
        {[{icon:"🔔",label:"Notificaciones",sub:"5 días antes del vencimiento"},{icon:"🔒",label:"Privacidad",sub:"Solo lectura · No guardamos facturas"}].map(function(r, i) {
          return (
            <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"13px 0",borderBottom:i===0?"1px solid #f9f9f9":"none"}}>
              <div style={{display:"flex",gap:10,alignItems:"center"}}>
                <span style={{fontSize:18}}>{r.icon}</span>
                <div>
                  <p style={{fontWeight:600,color:"#111",fontSize:13,margin:"0 0 1px"}}>{r.label}</p>
                  <p style={{color:"#a1a1aa",fontSize:11,margin:0}}>{r.sub}</p>
                </div>
              </div>
              <GhostBtn style={{padding:"5px 12px",borderRadius:8,fontSize:11}}>Editar</GhostBtn>
            </div>
          );
        })}
      </div>
      <button style={{width:"100%",padding:"13px",background:"#fff",border:"1.5px solid #fecaca",borderRadius:12,color:"#dc2626",fontWeight:700,fontSize:13,cursor:"pointer"}}>Cerrar sesión</button>
    </div>
  );
}


// ── Urgent Modal ──────────────────────────────────────────────────────────────
function UrgentModal({ bills, onClose, onNegotiate }) {
  return (
    <div style={{position:"fixed",inset:0,zIndex:150,display:"flex",alignItems:"flex-end"}} onClick={onClose}>
      <div style={{width:"100%",maxWidth:420,margin:"0 auto",background:"#fff",borderRadius:"24px 24px 0 0",padding:"8px 0 40px",boxShadow:"0 -8px 40px rgba(0,0,0,.15)"}} onClick={function(e){e.stopPropagation();}}>
        {/* handle */}
        <div style={{width:36,height:4,background:"#e4e4e7",borderRadius:2,margin:"12px auto 20px"}} />
        
        <div style={{padding:"0 20px"}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:20}}>
            <div style={{width:38,height:38,background:"#fffbeb",border:"1.5px solid #fcd34d",borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>⚠️</div>
            <div>
              <p style={{fontFamily:"'Syne',sans-serif",fontWeight:800,color:"#111",fontSize:16,margin:"0 0 1px"}}>Facturas próximas a vencer</p>
              <p style={{color:"#a1a1aa",fontSize:12,margin:0}}>Negocia antes de pagar</p>
            </div>
          </div>

          {bills.map(function(b) {
            var isToday    = b.dueIn <= 1;
            var isVerySoon = b.dueIn <= 3;
            var isSoon     = b.dueIn <= 7;
            var dotColor   = isToday ? "#dc2626" : isVerySoon ? "#ef4444" : isSoon ? "#f59e0b" : "#a1a1aa";
            var bgColor    = isToday ? "#fef2f2" : isVerySoon ? "#fff8f8" : "#fffbeb";
            var borderColor= isToday ? "#fecaca" : isVerySoon ? "#fee2e2" : "#fde68a";
            var label      = isToday ? "¡Vence hoy!" : b.dueIn <= 3 ? "En " + b.dueIn + " días" : b.dueDate;

            return (
              <div key={b.id} style={{background:bgColor,border:"1.5px solid " + borderColor,borderRadius:14,padding:"14px 16px",marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                  <div style={{display:"flex",gap:10,alignItems:"center"}}>
                    <div style={{width:38,height:38,background:"#fff",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,border:"1px solid #f0f0f0"}}>{b.icon}</div>
                    <div>
                      <p style={{fontWeight:700,color:"#111",fontSize:14,margin:"0 0 2px"}}>{b.provider}</p>
                      <p style={{color:"#71717a",fontSize:11,margin:0}}>{b.category}</p>
                    </div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <p style={{fontFamily:"'DM Serif Display',serif",fontWeight:400,color:"#111",fontSize:18,margin:"0 0 2px"}}>{b.amount ? fmt(b.amount) : "—"}</p>
                    <div style={{display:"flex",alignItems:"center",gap:5,justifyContent:"flex-end"}}>
                      <div style={{width:6,height:6,borderRadius:"50%",background:dotColor,animation:isToday?"pulse 1s ease infinite":"none"}} />
                      <span style={{color:dotColor,fontSize:11,fontWeight:700}}>{label}</span>
                    </div>
                  </div>
                </div>

                {/* Progress bar to due date */}
                <div style={{marginBottom:10}}>
                  <div style={{height:4,background:"#f0f0f0",borderRadius:2,overflow:"hidden"}}>
                    <div style={{height:"100%",borderRadius:2,background:dotColor,width:Math.max(10, 100 - (b.dueIn / 30) * 100) + "%",transition:"width .6s ease"}} />
                  </div>
                  <p style={{color:"#a1a1aa",fontSize:9,margin:"4px 0 0",textAlign:"right"}}>
                    {b.dueIn <= 1 ? "¡Último día!" : b.dueIn + " días restantes"}
                  </p>
                </div>

                {b.negotiable && b.savings > 0 && (
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <span style={{color:"#16a34a",fontSize:11,fontWeight:700}}>💡 Ahorra ~${b.savings}/mes si negocias</span>
                    <button onClick={function() { onNegotiate(b); onClose(); }} style={{padding:"6px 14px",background:"#111",border:"none",borderRadius:20,color:"#fff",fontWeight:700,fontSize:11,cursor:"pointer"}}>
                      Negociar →
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}


// ── Onboarding ────────────────────────────────────────────────────────────────
function Onboarding({ onDone }) {
  const [step, setStep] = useState(0);
  const slides = [
    { emoji:"💸", color:"#111", title:"Deja de pagar de más", sub:"BillSlayer analiza tus facturas y encuentra exactamente cuánto dinero estás dejando sobre la mesa cada mes.", tag:"Promedio: $1,247 ahorrados/año" },
    { emoji:"🤖", color:"#0f172a", title:"IA que negocia contigo", sub:"Mientras hablas con tu proveedor, nuestra IA te dice exactamente qué decir en tiempo real para bajar tu precio.", tag:"Tasa de éxito: 73%" },
    { emoji:"📸", color:"#1c1c2e", title:"Sube tu factura en segundos", sub:"Toma una foto de cualquier factura. La IA lee los datos automáticamente y genera tu estrategia personalizada.", tag:"Cualquier proveedor · Cualquier factura" },
  ];
  const s = slides[step];
  return (
    <div style={{minHeight:"100vh",background:s.color,display:"flex",flexDirection:"column",transition:"background .5s ease"}}>
      <style>{G}</style>
      {/* skip */}
      <div style={{display:"flex",justifyContent:"flex-end",padding:"16px 20px"}}>
        <button onClick={onDone} style={{background:"rgba(255,255,255,.1)",border:"none",borderRadius:20,padding:"6px 14px",color:"rgba(255,255,255,.6)",fontSize:12,fontWeight:600,cursor:"pointer"}}>Saltar</button>
      </div>

      {/* content */}
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"0 32px",textAlign:"center"}}>
        <div style={{width:100,height:100,background:"rgba(255,255,255,.08)",borderRadius:28,display:"flex",alignItems:"center",justifyContent:"center",fontSize:46,marginBottom:32,boxShadow:"0 8px 32px rgba(0,0,0,.2)"}}>
          {s.emoji}
        </div>
        <h1 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:30,color:"#fff",marginBottom:14,lineHeight:1.15,letterSpacing:"-.5px"}}>{s.title}</h1>
        <p style={{color:"rgba(255,255,255,.55)",fontSize:15,lineHeight:1.7,marginBottom:24,maxWidth:300}}>{s.sub}</p>
        <div style={{background:"rgba(255,255,255,.1)",borderRadius:20,padding:"8px 16px"}}>
          <span style={{color:"rgba(255,255,255,.7)",fontSize:12,fontWeight:600}}>{s.tag}</span>
        </div>
      </div>

      {/* bottom */}
      <div style={{padding:"24px 24px 48px"}}>
        {/* dots */}
        <div style={{display:"flex",justifyContent:"center",gap:6,marginBottom:24}}>
          {slides.map(function(_, i) {
            return <div key={i} style={{height:4,borderRadius:2,background:"rgba(255,255,255,.3)",width:i===step?24:8,transition:"all .3s ease",background:i===step?"#fff":"rgba(255,255,255,.3)"}} />;
          })}
        </div>
        <button onClick={function() { if (step < slides.length-1) setStep(step+1); else onDone(); }}
          style={{width:"100%",padding:"15px",background:"#fff",border:"none",borderRadius:14,fontSize:15,fontWeight:800,cursor:"pointer",fontFamily:"'Syne',sans-serif",color:"#111",boxShadow:"0 4px 20px rgba(0,0,0,.2)"}}>
          {step < slides.length-1 ? "Continuar →" : "¡Empezar a ahorrar!"}
        </button>
      </div>
    </div>
  );
}

// ── Empty State ───────────────────────────────────────────────────────────────
function EmptyState({ onScan, onConnect }) {
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"48px 24px",textAlign:"center"}}>
      <div style={{width:80,height:80,background:"#f4f4f5",borderRadius:24,display:"flex",alignItems:"center",justifyContent:"center",fontSize:36,marginBottom:20}}>📭</div>
      <h3 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:20,color:"#111",marginBottom:8}}>No hay facturas aún</h3>
      <p style={{color:"#a1a1aa",fontSize:13,lineHeight:1.7,marginBottom:28,maxWidth:260}}>Conecta tu Gmail para detectarlas automáticamente, o sube una foto de tu factura.</p>
      <div style={{display:"flex",flexDirection:"column",gap:10,width:"100%",maxWidth:280}}>
        <button onClick={onConnect} style={{padding:"13px",background:"#111",border:"none",borderRadius:12,color:"#fff",fontWeight:700,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
          📧 Conectar Gmail
        </button>
        <button onClick={onScan} style={{padding:"13px",background:"#f4f4f5",border:"none",borderRadius:12,color:"#111",fontWeight:700,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
          📸 Subir factura manualmente
        </button>
      </div>
    </div>
  );
}

// ── Success Celebration ───────────────────────────────────────────────────────
function SuccessCelebration({ saved, provider, onClose }) {
  const annual = saved * 12;
  const [show, setShow] = useState(false);
  useEffect(function() { setTimeout(function() { setShow(true); }, 100); }, []);
  return (
    <div style={{position:"fixed",inset:0,zIndex:400,background:"rgba(0,0,0,.7)",display:"flex",alignItems:"center",justifyContent:"center",padding:24}} onClick={onClose}>
      <div onClick={function(e){e.stopPropagation();}} style={{background:"#fff",borderRadius:24,padding:"40px 28px",maxWidth:340,width:"100%",textAlign:"center",transform:show?"scale(1)":"scale(.8)",opacity:show?1:0,transition:"all .4s cubic-bezier(.34,1.56,.64,1)"}}>
        {/* confetti emoji burst */}
        <div style={{fontSize:48,marginBottom:8,animation:"up .5s ease"}}>🎉</div>
        <div style={{display:"flex",justifyContent:"center",gap:8,marginBottom:20,flexWrap:"wrap"}}>
          {["🎊","⭐","💚","🏆","✨"].map(function(e,i) {
            return <span key={i} style={{fontSize:20,animation:"up .3s ease " + (i*.08) + "s both"}}>{e}</span>;
          })}
        </div>
        <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:26,color:"#111",marginBottom:6}}>¡Lo lograste!</h2>
        <p style={{color:"#71717a",fontSize:14,marginBottom:24}}>Negociaste tu factura de {provider}</p>
        <div style={{background:"linear-gradient(135deg,#f0fdf4,#dcfce7)",border:"2px solid #86efac",borderRadius:18,padding:"20px",marginBottom:24}}>
          <p style={{color:"#16a34a",fontSize:12,fontWeight:700,textTransform:"uppercase",letterSpacing:".5px",margin:"0 0 4px"}}>Ahorro mensual</p>
          <p style={{fontFamily:"'DM Serif Display',serif",color:"#111",fontSize:44,margin:"0 0 8px",lineHeight:1}}>-${saved}/mo</p>
          <div style={{height:1,background:"#86efac",margin:"12px 0"}} />
          <p style={{color:"#16a34a",fontSize:13,fontWeight:700,margin:0}}>= ${annual} al año en tu bolsillo 💰</p>
        </div>
        <button onClick={onClose} style={{width:"100%",padding:"13px",background:"#111",border:"none",borderRadius:12,color:"#fff",fontWeight:700,fontSize:14,cursor:"pointer"}}>
          Ver mi historial →
        </button>
      </div>
    </div>
  );
}

// ── Search Bar ────────────────────────────────────────────────────────────────
function SearchBar({ value, onChange }) {
  return (
    <div style={{position:"relative",marginBottom:12}}>
      <div style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:"#a1a1aa",fontSize:16,pointerEvents:"none"}}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      </div>
      <input value={value} onChange={onChange} placeholder="Buscar factura…"
        style={{width:"100%",padding:"10px 14px 10px 38px",border:"1.5px solid #f0f0f0",borderRadius:12,fontSize:13,background:"#fff",color:"#111",fontFamily:"'Plus Jakarta Sans',sans-serif"}}
        onFocus={function(e){e.target.style.borderColor="#111";}} onBlur={function(e){e.target.style.borderColor="#f0f0f0";}} />
    </div>
  );
}
// ── Root ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [screen,   setScreen]   = useState("login");
  const [user,     setUser]     = useState(null);
  const [tab,      setTab]      = useState("home");
  const [bills,    setBills]    = useState(BILLS);
  const [history,  setHistory]  = useState(HISTORY_INIT);
  const [sel,      setSel]      = useState(null);
  const [liveNeg,  setLiveNeg]  = useState(null);
  const [showScan, setShowScan] = useState(false);
  const [showUrgent,   setShowUrgent]   = useState(false);
  const [showOnboard,  setShowOnboard]  = useState(true);
  const [celebration,  setCelebration]  = useState(null);
  const [search,       setSearch]       = useState('');
  const [emails,   setEmails]   = useState([{id:1,address:"saimmosstoro@gmail.com",bills:5,connected:true,primary:true}]);

  if (showOnboard) {
    return <Onboarding onDone={function() { setShowOnboard(false); }} />;
  }
  if (screen === "login") {
    return <Login onLogin={function(u) { setUser(u); setScreen("app"); }} />;
  }

  var urgent     = bills.filter(function(b) { return b.dueIn <= 10; });
  var potential  = bills.filter(function(b) { return b.negotiable; }).reduce(function(s, b) { return s + (b.savings||0)*12; }, 0);
  var savedNow   = history.filter(function(h) { return h.ok; }).reduce(function(s, h) { return s + h.saved; }, 0);
  var negotiable = bills.filter(function(b) { return b.negotiable; }).length;
  var overpriced = bills.filter(function(b) { return b.amount && b.marketAvg && b.amount > b.marketAvg; }).length;
  var soonDue    = bills.filter(function(b) { return b.dueIn <= 10; }).length;

  var NAV = [
    {id:"home",    icon:NavIcons.home,    label:"Inicio"   },
    {id:"scan",    icon:NavIcons.scan,    label:"Escanear" },
    {id:"live",    icon:NavIcons.live,    label:"Negociar" },
    {id:"history", icon:NavIcons.history, label:"Historial"},
    {id:"profile", icon:NavIcons.profile, label:"Perfil"   },
  ];

  return (
    <div style={{minHeight:"100vh",background:"#f9fafb",paddingBottom:84}}>
      <style>{G}</style>
      {showScan && <ScanModal onClose={function() { setShowScan(false); }} onAdd={function(b) { setBills(function(p) { return [b,...p]; }); }} />}
      {showUrgent && <UrgentModal bills={urgent} onClose={function() { setShowUrgent(false); }} onNegotiate={function(b) { setLiveNeg(b); setShowUrgent(false); }} />}
      {celebration && <SuccessCelebration saved={celebration.saved} provider={celebration.provider} onClose={function() { setCelebration(null); setTab('history'); }} />}
      {liveNeg  && <LiveNeg  bill={liveNeg} onClose={function() { setLiveNeg(null); }} onSave={function(item) { setHistory(function(p) { return [item,...p]; }); setLiveNeg(null); if(item.ok && item.saved > 0) { setCelebration({saved:item.saved, provider:item.provider}); } else { setTab('history'); } }} />}

      <div style={{maxWidth:420,margin:"0 auto",padding:"0 20px"}}>

        {/* topbar */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"18px 0 14px"}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <div style={{width:32,height:32,background:"#111",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 2px 8px rgba(0,0,0,.12)"}}><span style={{color:"#fff",fontFamily:"'DM Serif Display',serif",fontWeight:700,fontSize:17,lineHeight:1}}>$</span></div>
            <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:20,color:"#111",letterSpacing:"-.3px"}}>BillSlayer</span>
          </div>
          <div style={{background:"#ecfdf5",borderRadius:20,padding:"4px 11px",display:"flex",alignItems:"center",gap:5}}>
            <div style={{width:6,height:6,borderRadius:"50%",background:"#16a34a",animation:"pulse 2s ease infinite"}} />
            <span style={{color:"#065f46",fontSize:11,fontWeight:700}}>Gmail</span>
          </div>
        </div>

        {/* HOME */}
        {tab === "home" && !sel && (
          <div style={{animation:"up .3s ease"}}>

            {/* hero */}
            <div style={{background:"linear-gradient(135deg,#111 0%,#1c1c2e 100%)",borderRadius:22,padding:"22px 20px",marginBottom:14,boxShadow:"0 8px 32px rgba(0,0,0,.14)"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
                <div>
                  <p style={{color:"#525252",fontSize:11,textTransform:"uppercase",letterSpacing:"1.4px",margin:"0 0 4px"}}>Ahorro potencial / año</p>
                  <p style={{fontFamily:"'DM Serif Display',serif",color:"#fff",fontSize:44,fontWeight:900,lineHeight:1,margin:"0 0 4px"}}>${potential.toLocaleString()}</p>
                  {savedNow > 0 && <p style={{color:"#4ade80",fontSize:12,margin:0}}>✓ Ahorrando ${savedNow}/mes ahora</p>}
                </div>
              </div>
              <div style={{borderTop:"1px solid rgba(255,255,255,.06)",paddingTop:12,display:"flex",gap:6}}>
                {[["Negociables", negotiable, "#4ade80"], ["Sobre mercado", overpriced, "#f87171"], ["Vencen pronto", soonDue, "#fbbf24"]].map(function(item) {
                  return (
                    <div key={item[0]} style={{flex:1,background:"rgba(255,255,255,.05)",borderRadius:8,padding:"7px 4px",textAlign:"center"}}>
                      <p style={{color:item[2],fontFamily:"'DM Serif Display',serif",fontWeight:900,fontSize:18,margin:"0 0 2px"}}>{item[1]}</p>
                      <p style={{color:"#525252",fontSize:9,lineHeight:1.3}}>{item[0]}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {urgent.length > 0 && (
              <div onClick={function() { setShowUrgent(true); }} style={{background:"#fffbeb",border:"1.5px solid #fcd34d",borderRadius:12,padding:"12px 14px",marginBottom:12,display:"flex",gap:10,alignItems:"center",cursor:"pointer",transition:"all .15s"}}
                onMouseOver={function(e){e.currentTarget.style.background="#fef9c3";}}
                onMouseOut={function(e){e.currentTarget.style.background="#fffbeb";}}>
                <span style={{fontSize:16}}>⚠️</span>
                <div style={{flex:1}}>
                  <p style={{fontWeight:700,color:"#92600a",fontSize:13,margin:"0 0 1px"}}>{urgent.length} factura{urgent.length > 1 ? "s" : ""} vence{urgent.length > 1 ? "n" : ""} pronto</p>
                  <p style={{color:"#b45309",fontSize:11,margin:0}}>Toca para ver fechas y negociar</p>
                </div>
                <div style={{width:28,height:28,background:"#fde68a",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <span style={{color:"#92600a",fontSize:13}}>→</span>
                </div>
              </div>
            )}

            {/* Monthly summary */}
            {savedNow > 0 && (
              <div style={{background:"linear-gradient(135deg,#f0fdf4,#dcfce7)",border:"1.5px solid #86efac",borderRadius:14,padding:"14px 16px",marginBottom:12,display:"flex",gap:12,alignItems:"center"}}>
                <div style={{width:38,height:38,background:"#fff",borderRadius:11,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>📈</div>
                <div style={{flex:1}}>
                  <p style={{fontWeight:700,color:"#14532d",fontSize:13,margin:"0 0 2px"}}>Este mes has ahorrado</p>
                  <p style={{fontFamily:"'DM Serif Display',serif",color:"#16a34a",fontSize:22,margin:0}}>${savedNow}/mes · ${savedNow*12}/año</p>
                </div>
              </div>
            )}

            {/* Search */}
            <SearchBar value={search} onChange={function(e) { setSearch(e.target.value); }} />

            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <p style={{fontWeight:700,color:"#111",fontSize:14}}>Tus facturas</p>
              <Tag tone="gray">{bills.filter(function(b){return b.provider.toLowerCase().includes(search.toLowerCase());}).length} detectadas</Tag>
            </div>

            {bills.filter(function(b){return b.provider.toLowerCase().includes(search.toLowerCase()) || b.category.toLowerCase().includes(search.toLowerCase());}).length === 0 && (
              <EmptyState onScan={function(){setShowScan(true);}} onConnect={function(){}} />
            )}

            {bills.filter(function(b){return b.provider.toLowerCase().includes(search.toLowerCase()) || b.category.toLowerCase().includes(search.toLowerCase());}).map(function(b, i) {
              return (
                <div key={b.id} onClick={function() { setSel(b); }}
                  style={{background:"#fff",borderRadius:18,marginBottom:9,cursor:"pointer",overflow:"hidden",boxShadow:"0 1px 4px rgba(0,0,0,.05)",border:"1.5px solid #f0f0f0"}}
                  onMouseOver={function(e) { e.currentTarget.style.boxShadow="0 4px 16px rgba(0,0,0,.09)"; e.currentTarget.style.borderColor="#d4d4d8"; }}
                  onMouseOut={function(e) { e.currentTarget.style.boxShadow="0 1px 4px rgba(0,0,0,.05)"; e.currentTarget.style.borderColor="#f0f0f0"; }}>

                  <div style={{height:3,background:b.dueIn<=5?"#ef4444":b.dueIn<=10?"#f59e0b":"#e4e4e7",borderRadius:"18px 18px 0 0"}} />

                  <div style={{padding:"14px 15px"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:11}}>
                      <div style={{display:"flex",gap:10,alignItems:"center"}}>
                        {b.photoData
                          ? <img src={b.photoData} alt="" style={{width:40,height:40,borderRadius:11,objectFit:"cover"}} />
                          : <div style={{width:40,height:40,background:"#f4f4f5",borderRadius:11,display:"flex",alignItems:"center",justifyContent:"center",fontSize:19}}>{b.icon}</div>
                        }
                        <div>
                          <p style={{fontWeight:700,color:"#111",fontSize:14,margin:"0 0 2px"}}>{b.provider}</p>
                          <p style={{color:"#a1a1aa",fontSize:11,margin:0}}>{b.category}</p>
                        </div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        {b.amount && b.savings > 0 ? (
                          <div style={{display:"flex",alignItems:"center",gap:5,justifyContent:"flex-end",marginBottom:2}}>
                            <span style={{fontFamily:"'DM Serif Display',serif",fontWeight:700,color:"#a1a1aa",fontSize:14,textDecoration:"line-through"}}>{fmt(b.amount)}</span>
                            <span style={{color:"#c4c4c4",fontSize:12}}>→</span>
                            <span style={{fontFamily:"'DM Serif Display',serif",fontWeight:900,color:"#16a34a",fontSize:17}}>{fmt(b.amount - b.savings)}</span>
                          </div>
                        ) : (
                          <p style={{fontFamily:"'DM Serif Display',serif",fontWeight:700,color:"#111",fontSize:17,margin:"0 0 2px"}}>{b.amount ? fmt(b.amount) : "—"}</p>
                        )}
                        <p style={{color:"#a1a1aa",fontSize:10,margin:0}}>ahorra ~${b.savings}/mes</p>
                      </div>
                    </div>

                    <div style={{marginBottom:2}}><PriceBar amount={b.amount} marketAvg={b.marketAvg} savings={b.savings} /></div>

                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:10}}>
                      <div style={{display:"flex",gap:5}}>
                        {b.negotiable ? <Tag tone="green">Negociable</Tag> : <Tag tone="gray">Fijo</Tag>}
                        <Tag tone={b.dueIn<=5?"red":b.dueIn<=10?"amber":"gray"}>{b.dueIn<=1?"¡Hoy!":b.dueDate}</Tag>
                      </div>
                      {b.negotiable && (
                        <button onClick={function(e) { e.stopPropagation(); setLiveNeg(b); }} style={{padding:"6px 14px",background:"#111",border:"none",borderRadius:20,color:"#fff",fontWeight:700,fontSize:11,cursor:"pointer",letterSpacing:".2px"}}>Negociar →</button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* BILL DETAIL */}
        {tab === "home" && sel && (
          <div style={{animation:"up .3s ease"}}>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
              <button onClick={function() { setSel(null); }} style={{width:34,height:34,borderRadius:"50%",border:"1.5px solid #e4e4e7",background:"#fff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>←</button>
              <div style={{flex:1}}>
                <h2 style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:19,color:"#111",margin:"0 0 1px"}}>{sel.provider}</h2>
                <p style={{color:"#a1a1aa",fontSize:12,margin:0}}>{sel.category}</p>
              </div>
            </div>

            {sel.photoData && <div style={{borderRadius:14,overflow:"hidden",marginBottom:12,height:150}}><img src={sel.photoData} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}} /></div>}

            {/* Price bar */}
            <div style={{marginBottom:12}}>
              <PriceBar amount={sel.amount} marketAvg={sel.marketAvg} savings={sel.savings} />
            </div>

            {/* Amount card */}
            <div style={{background:"linear-gradient(135deg,#111,#1c1c2e)",borderRadius:16,padding:18,marginBottom:12}}>
              <p style={{color:"#525252",fontSize:11,textTransform:"uppercase",letterSpacing:"1px",margin:"0 0 3px"}}>Pago mensual</p>
              {sel.amount && sel.savings > 0 ? (
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
                  <span style={{fontFamily:"'DM Serif Display',serif",color:"#a1a1aa",fontSize:28,textDecoration:"line-through"}}>{fmt(sel.amount)}</span>
                  <span style={{color:"#525252",fontSize:20}}>→</span>
                  <span style={{fontFamily:"'DM Serif Display',serif",color:"#4ade80",fontSize:36,fontWeight:900}}>{fmt(sel.amount - sel.savings)}</span>
                </div>
              ) : (
                <p style={{fontFamily:"'DM Serif Display',serif",color:"#fff",fontSize:36,fontWeight:900,margin:"0 0 6px"}}>{fmt(sel.amount||0)}</p>
              )}
              <p style={{color:"#525252",fontSize:12,lineHeight:1.6,margin:0}}>{sel.tip}</p>
            </div>

            {/* Provider info */}
            {PROVIDER_INFO[sel.provider] && (
              <div style={{background:"#fff",border:"1.5px solid #f0f0f0",borderRadius:16,padding:16,marginBottom:12}}>
                <div style={{display:"flex",gap:10,alignItems:"flex-start",paddingBottom:12,borderBottom:"1px solid #f9f9f9",marginBottom:12}}>
                  <div style={{width:36,height:36,background:"#f0fdf4",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>📞</div>
                  <div>
                    <p style={{fontWeight:700,color:"#111",fontSize:13,margin:"0 0 2px"}}>{PROVIDER_INFO[sel.provider].phone}</p>
                    <p style={{color:"#a1a1aa",fontSize:11,margin:"0 0 1px"}}>🕐 {PROVIDER_INFO[sel.provider].hours}</p>
                    <p style={{color:"#16a34a",fontSize:11,margin:0,fontWeight:600}}>⚡ Mejor hora: {PROVIDER_INFO[sel.provider].best}</p>
                  </div>
                </div>

                <p style={{fontWeight:700,color:"#111",fontSize:12,textTransform:"uppercase",letterSpacing:".5px",margin:"0 0 10px"}}>💡 Por qué puedes bajar tu precio</p>
                <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:14}}>
                  {PROVIDER_INFO[sel.provider].reasons.map(function(r, i) {
                    return (
                      <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                        <div style={{width:18,height:18,borderRadius:"50%",background:"#eff6ff",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>
                          <span style={{color:"#1d4ed8",fontSize:9,fontWeight:800}}>{i+1}</span>
                        </div>
                        <p style={{color:"#52525b",fontSize:12,lineHeight:1.6,margin:0}}>{r}</p>
                      </div>
                    );
                  })}
                </div>

                <p style={{fontWeight:700,color:"#111",fontSize:12,textTransform:"uppercase",letterSpacing:".5px",margin:"0 0 10px"}}>🎯 Tácticas que funcionan</p>
                <div style={{display:"flex",flexDirection:"column",gap:7}}>
                  {PROVIDER_INFO[sel.provider].tactics.map(function(t, i) {
                    return (
                      <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                        <span style={{color:"#16a34a",fontWeight:800,fontSize:12,flexShrink:0}}>✓</span>
                        <p style={{color:"#52525b",fontSize:12,lineHeight:1.6,margin:0}}>{t}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* History for this provider */}
            {history.filter(function(h) { return h.provider === sel.provider; }).length > 0 && (
              <div style={{background:"#fff",border:"1.5px solid #f0f0f0",borderRadius:14,padding:14,marginBottom:12}}>
                <p style={{fontWeight:700,color:"#111",fontSize:13,marginBottom:10}}>📋 Historial con {sel.provider}</p>
                {history.filter(function(h) { return h.provider === sel.provider; }).map(function(h) {
                  return (
                    <div key={h.id} style={{display:"flex",gap:8,alignItems:"center",padding:"8px 0",borderBottom:"1px solid #f9f9f9"}}>
                      <span style={{fontSize:14}}>{h.ok ? "✅" : "❌"}</span>
                      <div style={{flex:1}}>
                        <p style={{fontSize:12,color:"#111",fontWeight:600,margin:"0 0 1px"}}>{h.date}</p>
                        <p style={{fontSize:11,color:"#a1a1aa",margin:0}}>{h.ok ? "-$" + h.saved + "/mes" : "Sin cambio"}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {sel.negotiable && (
              <PrimaryBtn onClick={function() { setLiveNeg(sel); }} style={{borderRadius:14,boxShadow:"0 4px 16px rgba(0,0,0,.1)"}}>
                🎯 Iniciar negociación en vivo
              </PrimaryBtn>
            )}
          </div>
        )}

        {tab === "history" && <HistoryScreen items={history} />}
        {tab === "profile" && <ProfileScreen user={user} emails={emails} setEmails={setEmails} />}
      </div>

      {/* bottom nav */}
      <div style={{position:"fixed",bottom:0,left:0,right:0,background:"rgba(255,255,255,.97)",backdropFilter:"blur(20px)",borderTop:"1px solid #f0f0f0",padding:"10px 0 20px",zIndex:40}}>
        <div style={{maxWidth:420,margin:"0 auto",display:"flex",justifyContent:"space-around"}}>
          {NAV.map(function(n) {
            var isActive = tab === n.id && n.id !== "scan" && n.id !== "live";
            return (
              <button key={n.id}
                onClick={function() {
                  if (n.id === "scan") { setShowScan(true); return; }
                  if (n.id === "live") { setLiveNeg(bills.find(function(b) { return b.negotiable; }) || bills[0]); return; }
                  setTab(n.id); setSel(null);
                }}
                style={{background:"none",border:"none",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:4,padding:"4px 12px",color:isActive?"#111":"#c4c4c4"}}>
                <div style={{opacity:isActive?1:.35}}>{n.icon}</div>
                <span style={{fontSize:9,fontWeight:700,letterSpacing:".3px"}}>{n.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
